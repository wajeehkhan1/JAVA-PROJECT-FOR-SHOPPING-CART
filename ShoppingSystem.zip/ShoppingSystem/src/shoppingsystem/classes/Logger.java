/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package shoppingsystem.classes;

public class Logger {
    public void log(String message) {
        // Log the message to the console
        System.out.println("[INFO] " + message);
    }
}
