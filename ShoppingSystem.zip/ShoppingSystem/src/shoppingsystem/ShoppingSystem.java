package shoppingsystem;

import java.sql.SQLException;
import java.util.Scanner;
import shoppingsystem.classes.*;
import java.sql.Connection;
import java.util.InputMismatchException;
import java.util.Iterator;
import java.util.List;

public class ShoppingSystem {
    private static final UserManager userManager = new UserManager();
    private static final ProductCatalog productCatalog = new ProductCatalog();
    private static final MockPaymentGateway paymentGateway = new MockPaymentGateway();
    private static final Logger logger = new Logger();
    private static final OrderProcessor orderProcessor = new OrderProcessor(paymentGateway, logger);
    private static final CartBuilder cartBuilder = new CartBuilder();
    private static final Scanner scanner = new Scanner(System.in);
    private static int loggedIn_userId=-1;

    public static void main(String[] args) {
        boolean exit = false;

        while (!exit) {
            displayStartMenu();

            try {
                    int choice = scanner.nextInt();
                    scanner.nextLine();

                    switch (choice) {
                        case 1:
                            if (login()) {
                                displayFullMenu();
                            }
                            break;
                        case 2:
                            createAccount();
                            break;
                        case 3:
                            exit = true;
                            System.out.println("Exiting the Shopping System. Goodbye!");
                            break;
                        default:
                            System.out.println("Invalid choice. Please enter a number between 1 and 3.");
            }
                
            } catch (InputMismatchException e) {
                logger.log("Invalid input. Please enter a valid integer choice.");
                scanner.nextLine(); // Clear the scanner buffer
            } catch (SQLException e) {
                System.err.println("An error occurred: " + e.getMessage());
            }
        }
            scanner.close();
    }
    
    private static void displayStartMenu() {
            System.out.println("=== Shopping System Menu ===");
            System.out.println("1. Login");
            System.out.println("2. Create Account");
            System.out.println("3. Exit");
            System.out.print("Enter your choice: ");
    }
     
    private static void displayFullMenu() throws SQLException {
        boolean exit = false;

        while (!exit) {
            System.out.println("\n=== Shopping System Menu ===");
            System.out.println("1. Browse Products");
            System.out.println("2. Add Item to Cart");
            System.out.println("3. View Cart");
            System.out.println("4. Place Order");
            System.out.println("5. Logout");
            System.out.println("6. Exit");
            System.out.print("Enter your choice: ");

            try {
                    int choice = scanner.nextInt();
                    scanner.nextLine(); // Consume newline

                    switch (choice) {
                        case 1:
                            browseProducts();
                            break;
                        case 2:
                            addItemToCart();
                            break;
                        case 3:
                            viewCart();
                            break;
                        case 4:
                            placeOrder();
                            break;
                        case 5:
                            logout();
                            exit = true; // Exit the loop to go back to the initial login/menu screen
                            break;
                        case 6:
                            exit = true;
                            System.out.println("Exiting the Shopping System. Goodbye!");
                            break;
                        default:
                            System.out.println("Invalid choice. Please enter a number between 1 and 6.");
                }
            } catch (InputMismatchException e) {
                logger.log("Invalid input. Please enter a valid integer choice.");
                scanner.nextLine(); // Clear the scanner buffer
            } catch (SQLException e) {
                System.err.println("An error occurred: " + e.getMessage());
            }
        }
    }



    private static boolean login() throws SQLException {
            System.out.print("Enter username: ");
            String username = scanner.nextLine();
            System.out.print("Enter password: ");
            String password = scanner.nextLine();
            loggedIn_userId = userManager.login(username, password);
            return loggedIn_userId != -1; // Return true if login successful, false otherwise
    }

    private static void createAccount() throws SQLException {
            System.out.print("Enter username: ");
            String username = scanner.nextLine();
            System.out.print("Enter password: ");
            String password = scanner.nextLine();
            userManager.createUser(username, password);
    }

    private static void browseProducts() throws SQLException {
            List<Product> products = productCatalog.getAllProducts();

            System.out.println("\n=== Products Catalog ===");
            if (products.isEmpty()) {
                System.out.println("No products available.");
            } else {
                System.out.println("ID\tName\t\tPrice\tDescription");
                for (Product product : products) {
                    System.out.println(product.getId() + "\t" + product.getName() + "\t$" + product.getPrice() + "\t" + product.getDescription());
                }
            }
    }


    private static void addItemToCart() throws SQLException {
            boolean addMoreItems = true;
            browseProducts();
            while (addMoreItems) {
                Scanner scanner = new Scanner(System.in);
               try{
                // Prompt the user to enter the product ID
                System.out.print("Enter the product ID: ");
                int productId = scanner.nextInt();

                // Prompt the user to enter the quantity
                System.out.print("Enter the quantity: ");
                int quantity = scanner.nextInt();

                // Add the item to the cart
                cartBuilder.addItem(productId, quantity);

                // Ask the user if they want to add more items
                System.out.print("Do you want to add more items to the cart? (yes/no): ");
                String addMore = scanner.next().trim().toLowerCase();
                addMoreItems = addMore.equals("yes");
               }
               catch (InputMismatchException e) {
                        logger.log("Invalid input. Please enter a valid integer choice.");
                        scanner.nextLine(); // Clear the scanner buffer
                    }

            }
}



    private static void viewCart() throws SQLException {
        try {
                    List<CartItem> items = cartBuilder.build().getItems();

                    if (items.isEmpty()) {
                        System.out.println("Your cart is empty.");
                    } else {
                        System.out.println("Items in your cart:");
                        for (CartItem item : items) {
                            System.out.println("Product ID: " + item.getProductId() + ", Name: " + item.getName() + ", Quantity: " + item.getQuantity() + ", Price: " + item.getPrice());
                        }
                        // Calculate and display the total price
                        double totalPrice = cartBuilder.totalPriceCart();
                        System.out.println("Total Price: $" + totalPrice);

                        // Prompt the user for additional actions
                        System.out.println("\nOptions:");
                        System.out.println("1. Edit Item");
                        System.out.println("2. Remove Item");
                        System.out.println("3. Return to Main Menu");
                        System.out.print("Enter your choice: ");

                        int choice = scanner.nextInt();
                        scanner.nextLine(); // Consume newline

                        switch (choice) {
                            case 1:
                                editItem(items);
                                break;
                            case 2:
                                removeItem(items);
                                break;
                            case 3:
                                return; // Return to the main menu
                            default:
                                System.out.println("Invalid choice.");
                        }
                }
            }
            catch (SQLException e) {
                System.err.println("Error occurred while viewing the cart: " + e.getMessage());
            }catch (InputMismatchException e) {
                logger.log("Invalid input. Please enter a valid integer choice.");
                scanner.nextLine(); // Clear the scanner buffer
                 }

}


    private static void editItem(List<CartItem> items) {
            try{
            Scanner scanner = new Scanner(System.in);
            System.out.print("Enter the product ID of the item you want to edit: ");
            int productId = scanner.nextInt();
            System.out.print("Enter the new quantity: ");
            int newQuantity = scanner.nextInt();

            // Find the item in the list and update its quantity
            for (CartItem item : items) {
                if (item.getProductId() == productId) {
                    item.setQuantity(newQuantity);
                    cartBuilder.editItem(productId, newQuantity);
                    System.out.println("Item quantity updated successfully.");
                    return;
                }
            }
            System.out.println("Item not found in the cart.");
            }
            catch (InputMismatchException e) {
                        logger.log("Invalid input. Please enter a valid integer choice.");
                        scanner.nextLine(); // Clear the scanner buffer
                    }
    }

    private static void removeItem(List<CartItem> items) {
            try{
            Scanner scanner = new Scanner(System.in);
            System.out.print("Enter the product ID of the item you want to remove: ");
            int productId = scanner.nextInt();

            // Find the item in the list and remove it
            for (Iterator<CartItem> iterator = items.iterator(); iterator.hasNext();) {
                CartItem item = iterator.next();
                if (item.getProductId() == productId) {
                    iterator.remove();
                    cartBuilder.removeItem(productId);
                    System.out.println("Item removed successfully.");
                    return;
                }
            }
            System.out.println("Item not found in the cart.");
            }
            catch (InputMismatchException e) {
                        logger.log("Invalid input. Please enter a valid integer choice.");
                        scanner.nextLine(); // Clear the scanner buffer
                    }
}




    private static void placeOrder() throws SQLException {
        try{
    // Validate if there are items in the cart
    List<CartItem> items = cartBuilder.build().getItems();
    if (items.isEmpty()) {
        System.out.println("Your cart is empty. Add items to your cart before placing an order.");
        return;
    }
    if(loggedIn_userId==-1){
    // Prompt the user to log in before placing the order
    System.out.print("Enter username: ");
    String username = scanner.nextLine();
    System.out.print("Enter password: ");
    String password = scanner.nextLine();

    // Attempt to log in the user
    int userId = userManager.login(username, password);
    if (userId == -1) {
        // Login failed, return without placing the order
        System.out.println("Login failed. Please try again.");
        return;
    }}

    // Create an order from the items in the cart
    Order order = new Order();
    for (CartItem item : items) {
        // Retrieve product details from the database and add to the order
        Product product = productCatalog.getProductById(item.getProductId());
        order.getProducts().add(product);
    }

    // Place the order using the order processor
    boolean orderPlaced = orderProcessor.placeOrder(order,loggedIn_userId,items,cartBuilder.totalPriceCart() );
    if (orderPlaced) {
        
        // Clear the cart after successful order placement
        cartBuilder.build().clearCart();
    } else {
        System.out.println("Failed to place the order. Please try again.");
    }}
        catch (InputMismatchException e) {
                logger.log("Invalid input. Please enter a valid integer choice.");
                scanner.nextLine(); // Clear the scanner buffer
            }
}



    private static void logout() throws SQLException {
    loggedIn_userId = -1;
    System.out.println("Logged out successfully.\n");
    // Display the start menu again
    
    }
   



}
