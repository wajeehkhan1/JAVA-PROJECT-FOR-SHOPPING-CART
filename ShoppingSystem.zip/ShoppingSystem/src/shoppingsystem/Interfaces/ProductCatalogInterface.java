package shoppingsystem.interfaces;

import shoppingsystem.classes.Product;

import java.sql.SQLException;
import java.util.List;

public interface ProductCatalogInterface {
 
    List<Product> getAllProducts() throws SQLException;

    void addProduct(Product product) throws SQLException;

    void removeProduct(int productId) throws SQLException;

}
