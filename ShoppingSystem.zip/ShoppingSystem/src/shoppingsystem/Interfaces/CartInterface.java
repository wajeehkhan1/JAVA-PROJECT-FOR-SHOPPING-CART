/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package shoppingsystem.interfaces;

import java.sql.SQLException;
import java.util.List;
import shoppingsystem.classes.CartItem;

public interface CartInterface {
  
    void addItem(int productId, int quantity);

    List<CartItem> getItems() throws SQLException;

    void removeItem(int productId);

    void editItem(int productId, int newQuantity);

    void clearCart();
}

